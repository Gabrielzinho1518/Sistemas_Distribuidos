import java.util.concurrent.locks.ReentrantLock;

public class CorridaComLock {

    static int contador = 0; 
    static ReentrantLock lock = new ReentrantLock(); // Lock para sincronização

    public static void main(String[] args) {

        // Thread 1
        Thread t1 = new Thread(() -> {
            for (int i = 0; i < 2000; i++) {
                lock.lock(); // Adquire o lock
                try {
                    contador++;
                } finally {
                    lock.unlock(); // Libera o lock, mesmo se ocorrer erro
                }
            }
        });

        // Thread 2
        Thread t2 = new Thread(() -> {
            for (int i = 0; i < 2000; i++) {
                lock.lock();
                try {
                    contador++;
                } finally {
                    lock.unlock();
                }
            }
        });

        // Inicia as threads
        t1.start();
        t2.start();

        // Aguarda as threads finalizarem
        try {
            t1.join();
            t2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Exibe o valor final do contador
        System.out.println("Valor final do contador (com lock): " + contador);
    }
}
