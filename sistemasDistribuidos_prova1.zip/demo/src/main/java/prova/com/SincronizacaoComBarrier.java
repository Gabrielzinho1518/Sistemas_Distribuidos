import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

public class SincronizacaoComBarrier {

    public static void main(String[] args) {

        // Cria a barreira para 4 threads, com uma ação após todas chegarem
        CyclicBarrier barreira = new CyclicBarrier(4, () -> {
            System.out.println("\n>>> Todas as threads completaram a primeira etapa. Prosseguindo...\n");
        });

        // Cria e inicia 4 threads
        for (int i = 1; i <= 4; i++) {
            final int id = i;
            new Thread(() -> {
                try {
                    // Primeira parte da tarefa
                    System.out.println("Thread " + id + " executando a primeira parte...");
                    Thread.sleep((long) (Math.random() * 2000)); // Simula trabalho

                    // Aguarda na barreira
                    System.out.println("Thread " + id + " aguardando as demais na barreira.");
                    barreira.await(); // Espera todas as threads chegarem aqui

                    // Segunda parte da tarefa
                    System.out.println("Thread " + id + " executando a segunda parte.");
                } catch (InterruptedException | BrokenBarrierException e) {
                    e.printStackTrace();
                }
            }).start();
        }
    }
}
