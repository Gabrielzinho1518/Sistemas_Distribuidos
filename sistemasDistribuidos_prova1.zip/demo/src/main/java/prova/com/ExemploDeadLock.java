public class ExemploDeadLock {

    // Dois recursos compartilhados
    static final Object recurso1 = new Object();
    static final Object recurso2 = new Object();

    public static void main(String[] args) {
        // Thread 1 tenta pegar recurso1 e depois recurso2
        Thread t1 = new Thread(() -> {
            synchronized (recurso1) {
                System.out.println("Thread 1 bloqueou recurso 1");

                try {
                    Thread.sleep(100); // Simula tempo de processamento
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                synchronized (recurso2) {
                    System.out.println("Thread 1 bloqueou recurso 2");
                }
            }
        });

        // Thread 2 tenta pegar recurso2 e depois recurso1 (ordem invertida)
        Thread t2 = new Thread(() -> {
            synchronized (recurso2) {
                System.out.println("Thread 2 bloqueou recurso 2");

                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                synchronized (recurso1) {
                    System.out.println("Thread 2 bloqueou recurso 1");
                }
            }
        });
        t1.start();
        t2.start();
    }
}
