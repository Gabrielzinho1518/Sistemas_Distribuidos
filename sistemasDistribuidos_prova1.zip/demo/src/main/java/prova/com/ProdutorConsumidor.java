import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class ProdutorConsumidor {

    private static final int TAMANHO_FILA = 5;

    public static void main(String[] args) {

        BlockingQueue<Integer> fila = new ArrayBlockingQueue<>(TAMANHO_FILA);
        Thread produtor = new Thread(() -> {
            for (int i = 1; i <= 10; i++) {
                try {
                    System.out.println("Produzindo: " + i);
                    fila.put(i); // bloqueia se a fila estiver cheia
                    Thread.sleep(500); // simula tempo de produção
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        });

        // Thread do consumidor
        Thread consumidor = new Thread(() -> {
            for (int i = 1; i <= 10; i++) {
                try {
                    int item = fila.take(); // bloqueia se a fila estiver vazia
                    System.out.println("Consumindo: " + item);
                    Thread.sleep(800); // simula tempo de consumo
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        });

        // Inicia as threads
        produtor.start();
        consumidor.start();

        // Espera ambas terminarem
        try {
            produtor.join();
            consumidor.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Fim da execução.");
    }
}
