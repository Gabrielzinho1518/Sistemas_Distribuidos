public class ParesImpares {

    public static void main(String[] args) {
        Thread pares = new Thread(() -> {
            for (int i = 0; i <= 20; i += 2) {
                System.out.println("Par: " + i);
                try {
                    Thread.sleep(1000); 
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        // Thread para imprimir números ímpares
        Thread impares = new Thread(() -> {
            for (int i = 1; i < 20; i += 2) {
                System.out.println("impar: " + i);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        pares.start();
        impares.start();
    }
}
