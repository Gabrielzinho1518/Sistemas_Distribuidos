import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class LamportRelogioLogico {

    static class Mensagem {
        int timestamp;
        String conteudo;

        public Mensagem(int timestamp, String conteudo) {
            this.timestamp = timestamp;
            this.conteudo = conteudo;
        }
    }

    static class Processo extends Thread {
        private int id;
        private int relogioLogico = 0;
        private BlockingQueue<Mensagem> minhaFila;
        private BlockingQueue<Mensagem> filaOutro;

        public Processo(int id, BlockingQueue<Mensagem> minhaFila, BlockingQueue<Mensagem> filaOutro) {
            this.id = id;
            this.minhaFila = minhaFila;
            this.filaOutro = filaOutro;
        }

        private void eventoLocal(String acao) {
            relogioLogico++;
            System.out.println("Processo " + id + " executou evento local (" + acao + ") - relogio: " + relogioLogico);
        }

        private void enviarMensagem(String conteudo) throws InterruptedException {
            relogioLogico++;
            Mensagem msg = new Mensagem(relogioLogico, conteudo);
            filaOutro.put(msg);
            System.out.println("Processo " + id + " enviou mensagem [" + conteudo + "] com timestamp " + relogioLogico);
        }

        private void receberMensagem() throws InterruptedException {
            Mensagem msg = minhaFila.take();
            // Atualiza relógio lógico
            relogioLogico = Math.max(relogioLogico, msg.timestamp) + 1;
            System.out.println("Processo " + id + " recebeu mensagem [" + msg.conteudo + "] com timestamp " + msg.timestamp + " - relogio atualizado: " + relogioLogico);
        }

        @Override
        public void run() {
            try {
                eventoLocal("inicio");
                Thread.sleep(500);

                enviarMensagem("Enviando mensagem do processo " + id);
                Thread.sleep(500);

                eventoLocal("processando dados");
                Thread.sleep(500);

                receberMensagem();
                Thread.sleep(500);

                eventoLocal("fim");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    public static void main(String[] args) {
        // Fila de comunicação entre os dois processos (como canais)
        BlockingQueue<Mensagem> fila1 = new LinkedBlockingQueue<>();
        BlockingQueue<Mensagem> fila2 = new LinkedBlockingQueue<>();

        // Cria os dois processos
        Processo p1 = new Processo(1, fila1, fila2);
        Processo p2 = new Processo(2, fila2, fila1);

        // Inicia as threads
        p1.start();
        p2.start();

        try {
            p1.join();
            p2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Simulacao concluida.");
    }
}
