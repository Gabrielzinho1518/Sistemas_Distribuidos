import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;

public class SomaThreadComParametro {

    // Classe que implementa Callable para permitir retorno da soma
    static class SomaThread implements Callable<Integer> {
        private final List<Integer> numeros;

        public SomaThread(List<Integer> numeros) {
            this.numeros = numeros;
        }

        @Override
        public Integer call() {
            int soma = 0;
            for (int num : numeros) {
                soma += num;
            }
            return soma;
        }
    }

    public static void main(String[] args) {
        // Lista de números a ser somada
        List<Integer> lista = Arrays.asList(10, 20, 30, 40, 50, 60);

        // Cria a thread com FutureTask e Callable
        FutureTask<Integer> tarefa = new FutureTask<>(new SomaThread(lista));
        Thread thread = new Thread(tarefa);
        thread.start();

        try {
            // Aguarda e obtém o resultado da soma
            int resultado = tarefa.get();
            System.out.println("Soma dos numeros: " + resultado);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
