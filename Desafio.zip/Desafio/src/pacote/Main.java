package pacote;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        int totalListas = 11;    
        int tamanhoLista = 1000;  //Números por lista  
        List<List<Integer>> listaDeListas = new ArrayList<>();

        for (int i = 0; i < totalListas; i++) {
            listaDeListas.add(new ArrayList<>());
        }

        List<PopulaLista> threads = new ArrayList<>();
        for (int i = 0; i < totalListas; i++) {
            PopulaLista t = new PopulaLista(listaDeListas.get(i), tamanhoLista);
            threads.add(t);
            t.start();
        }

        for (PopulaLista t : threads) {
            try {
                t.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        long soma = 0;
        long qtd = 0;
        for (List<Integer> lista : listaDeListas) {
            for (int num : lista) {
                soma += num;
                qtd++;
            }
        }
        double media = (double) soma / qtd;
        System.out.println("Média dos valores gerados em todas as listas: " + media);
    }
}