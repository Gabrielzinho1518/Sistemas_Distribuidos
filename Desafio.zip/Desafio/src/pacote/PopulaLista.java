package pacote;

import java.util.*;

class PopulaLista extends Thread {
 private List<Integer> lista;
 private int tamanho;
 private Random rand = new Random();

 public PopulaLista(List<Integer> lista, int tamanho) {
     this.lista = lista;
     this.tamanho = tamanho;
 }

 @Override
 public void run() {
     for (int i = 0; i < tamanho; i++) {
         int num = rand.nextInt(100000 - 1000 + 1) + 1000; 
         lista.add(num);
     }
     System.out.println("Thread " + this.getName() + " finalizada!");
 }
}