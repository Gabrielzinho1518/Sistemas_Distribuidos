import java.rmi.RemoteException;
import java.rmi.Remote;

public interface IHoje_eh extends Remote{
    public IHoje_eh pegaDataHora() throws RemoteException;

}