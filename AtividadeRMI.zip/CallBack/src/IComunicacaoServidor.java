import java.time.LocalDateTime;
import java.rmi.Remote;
import java.rmi.RemoteException;


public interface IComunicacaoServidor extends Remote {
    
    public void receberCliente(IComunicacaoCliente clientes, String ip, LocalDateTime dataHora) throws RemoteException;
    public void receberMensagemDoCliente(String msg) throws RemoteException;
}
