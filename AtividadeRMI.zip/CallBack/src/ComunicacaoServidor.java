import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ComunicacaoServidor extends UnicastRemoteObject implements IComunicacaoServidor {

    private ServidorFrame frame;
    private List<String> clientes = new ArrayList<>();

    public ComunicacaoServidor(ServidorFrame frame) throws RemoteException {
        this.frame = frame;
    }

    @Override
    public void receberCliente(IComunicacaoCliente cliente, String ip, LocalDateTime dataHora) throws RemoteException {
        String info = "Cliente conectado - IP: " + ip + " | Data/Hora: " + dataHora;
        clientes.add(info);
        frame.adicionaMsg(info);
    }

    @Override
    public void receberMensagemDoCliente(String msg) throws RemoteException {
        frame.adicionaMsg("Cliente: " + msg);
    }

    public void enviaMsgProCliente(String msg) throws RemoteException {
        frame.adicionaMsg("Servidor: " + msg);
    }

    public List<String> getClientes() {
        return clientes;
    }
}
